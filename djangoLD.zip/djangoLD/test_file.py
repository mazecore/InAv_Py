# -*- coding: utf-8 -*-
"""
Created on Sat Jun 15 00:07:27 2019

@author: Ldeezy
"""

login = 'ldeezzle'
password ='Boobsichka10!'

login2 = 'markovartist'
password2 = 'Boobsichka10'

boobslogin = 'granovski'
boobspassword = 'Prodigy12#'

database = { 'default': {
                    'ENGINE': 'django.db.backends.postgresql',
                    'NAME': 'postgres',
                    'USER': 'postgres',
                    'PASSWORD': 'Boobsichka10!',
                  
                    'PORT': '5432'
                }
           }

secretKey = '#dpoyz@sc!e#-v6+&-gb%xk&*op(nehbnl-nno&o2vr4iqa)rl'